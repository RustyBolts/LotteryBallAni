System.register([],(function(e){"use strict";return{execute:function(){e("default","assets/spine-a0005c42.wasm")}}}));
