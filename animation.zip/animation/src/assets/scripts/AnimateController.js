
AnimateController = {};
(function(){
    AnimateController.Input = function() {
        console.log("Input method called from external JavaScript.");
        
    }
})();