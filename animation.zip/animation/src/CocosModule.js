export default {
  data() {
    return {
      message: "Cocos 應用初始化消息" // 示例數據，可根據需要自定義
    };
  },
  mounted() {
    this.initCocosApp('app');
  },
  methods: {
    initCocosApp(containerId) {
      const container = document.getElementById(containerId);
      if (!container) {
        console.error('Cocos 應用容器未找到',containerId);
        return;
      }

      const scriptsToLoad = [
        './src/res.js',
        './src/polyfills.bundle.js',
        './src/system.bundle.js',
        './src/ajaxhook.min.js',
        './src/utils.js',
        './src/systemjs.js',
        './src/ajax.js',
        './src/fontloader.js',
        './src/game-start-up.js'
        // './src/app.js'
      ];
      
      scriptsToLoad.forEach(script => {
        const scriptTag = document.createElement('script');
        scriptTag.src = script;
        document.body.appendChild(scriptTag);
      });
    }
  }
};
