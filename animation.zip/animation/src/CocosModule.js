// CocosModule.js
export default function initCocosApp(containerId) {
  const container = document.getElementById(containerId);
  if (!container) {
    console.error('Cocos 應用容器未找到');
    return;
  }

  // 加載 polyfills.js
  const polyfillsScript = document.createElement('script');
  polyfillsScript.src = './src/polyfills.bundle.js';
  document.body.appendChild(polyfillsScript);

  // 加載 systemjs.bundle.js
  const systemjsScript = document.createElement('script');
  systemjsScript.src = './src/system.bundle.js';
  document.body.appendChild(systemjsScript);
  // <script src="src/import-map.json" type="systemjs-importmap" charset="utf-8"></script>

  // 加載 systemjs.js
  const systemjsScript2 = document.createElement('script');
  systemjsScript2.src = './src/system.js';
  document.body.appendChild(systemjsScript2);

  // 加載 ajaxhook.min.js
  const ajaxhookScript = document.createElement('script');
  ajaxhookScript.src = './src/ajaxhook.min.js';
  document.body.appendChild(ajaxhookScript);

  // 加載 utils.js
  const utilsScript = document.createElement('script');
  utilsScript.src = './src/utils.js'; // 替換為實際的路徑
  document.body.appendChild(utilsScript);

  // 加載 ajax.js
  const ajaxScript = document.createElement('script');
  ajaxScript.src = './src/ajax.js'; // 替換為實際的路徑
  document.body.appendChild(ajaxScript);

  // 加載 fontloader.js
  const fontloaderScript = document.createElement('script');
  fontloaderScript.src = './src/fontloader.js';
  document.body.appendChild(fontloaderScript);

  // 加載主體 res.js
  const resScript = document.createElement('script');
  resScript.src = './src/res.js'; // 替換為實際的路徑
  document.body.appendChild(resScript);

  // 加載 game-start-up.js
  const gamestartupScript = document.createElement('script');
  gamestartupScript.src = './src/game-start-up.js';
  document.body.appendChild(gamestartupScript);
}
