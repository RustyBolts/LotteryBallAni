<!-- 舊方法試寫 -->
<!-- <template>
  <div id="cocos-container"></div>
</template>

<script>
import initCocosApp from './CocosModule.js';

export default {
  mounted() {
    initCocosApp('cocos-container');
  }
};
</script> -->


<template>
  <div id="GameDiv" cc_exact_fit_screen="true">
    <div id="Cocos3dGameContainer">
      <canvas id="GameCanvas" @contextmenu.prevent="" tabindex="99"></canvas>
    </div>
  </div>
</template>

<!-- creator cc.js 路徑內容，寫在 res.js 裡面 -->
<script src="./import-map.json" type="systemjs-importmap" charset="utf-8"></script>

<script>
export default {
  name: 'CocosModule',
  mounted() {
    // 在這裡加載和初始化您的遊戲或其他腳本
    // 例如，使用 import() 函數動態導入腳本
    this.loadScripts();
  },
  methods: {
    async loadScripts() {
      await import('./src/CocosModule.js');
    }
  }
}
</script>

<style scoped>
html {
  -ms-touch-action: none;
}
body,
canvas,
div {
  display: block;
  outline: 0;
  -webkit-tap-highlight-color: transparent;
  user-select: none;
  -moz-user-select: none;
  -webkit-user-select: none;
  -ms-user-select: none;
  -khtml-user-select: none;
  -webkit-tap-highlight-color: transparent;
}
input::-webkit-inner-spin-button,
input::-webkit-outer-spin-button {
  -webkit-appearance: none;
  margin: 0;
}
body {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  padding: 0;
  border: 0;
  margin: 0;
  cursor: default;
  color: #888;
  background-color: #333;
  text-align: center;
  font-family: Helvetica, Verdana, Arial, sans-serif;
  display: flex;
  flex-direction: column;
}
canvas {
  background-color: rgba(0, 0, 0, 0);
}
#Cocos3dGameContainer,
#GameCanvas,
#GameDiv {
  width: 100%;
  height: 100%;
}
:root {
  --safe-top: env(safe-area-inset-top);
  --safe-right: env(safe-area-inset-right);
  --safe-bottom: env(safe-area-inset-bottom);
  --safe-left: env(safe-area-inset-left);
}
</style>
